package app

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/spf13/cobra"
)

type compactSummaryAnalyzerConfig struct {
	Symbols    []string
	Months     []string
	ChunksDir  string
	ReportsDir string
	Family     string
	Side       string
	Horizon    string
}

type compactSummaryChunk struct {
	Symbol          string
	Month           string
	AlphaPath       string
	SummaryPath     string
	AlphaRows       []FundingAlphaSummaryRow
	AlphaMissing    bool
	SummaryMissing  bool
	SummaryStatus   string
	ZeroEventMonth  bool
	UnexplainedZero bool
}

type compactThresholds struct {
	MinEventCount                   int     `json:"min_event_count"`
	MinClusterCount                 int     `json:"min_cluster_count"`
	CalibrationReadyEventCount      int     `json:"calibration_ready_event_count"`
	TopSymbolContributionFailPct    float64 `json:"top_symbol_contribution_fail_pct"`
	TopMonthContributionFailPct     float64 `json:"top_month_contribution_fail_pct"`
	TopQuarterContributionWarnPct   float64 `json:"top_quarter_contribution_warn_pct"`
	TopBucketContributionWarnPct    float64 `json:"top_bucket_contribution_warn_pct"`
	MinBaselinePF                   float64 `json:"min_baseline_pf"`
	MinResearchLeadPF               float64 `json:"min_research_lead_pf"`
	MaxDelayDecayFailPct            float64 `json:"max_delay_decay_fail_pct"`
	MaxShadowDelayDecayPct          float64 `json:"max_shadow_delay_decay_pct"`
	MinCost10PFForShadow            float64 `json:"min_cost_10_pf_for_shadow"`
	MinCost10ExpectancyForShadowBps float64 `json:"min_cost_10_expectancy_for_shadow_bps"`
}

type compactIntegrityReport struct {
	Status               string   `json:"status"`
	MonthsExpected       int      `json:"months_expected"`
	MonthsFound          int      `json:"months_found"`
	SymbolsExpected      int      `json:"symbols_expected"`
	SymbolsFound         int      `json:"symbols_found"`
	MissingSummaries     []string `json:"missing_summaries"`
	ZeroEventSummaries   []string `json:"zero_event_summaries"`
	UnexplainedZeroEvent []string `json:"unexplained_zero_event_summaries"`
	MissingRequired      []string `json:"missing_required_metrics"`
	RawRequired          bool     `json:"raw_required"`
}

type compactDimensionRow struct {
	Key                  string  `json:"key"`
	EventCount           int     `json:"event_count"`
	ClusterCount         int     `json:"cluster_count"`
	GrossProfitBps       float64 `json:"gross_profit_bps"`
	GrossLossBps         float64 `json:"gross_loss_bps"`
	NetBps               float64 `json:"net_bps"`
	ExpectancyBps        float64 `json:"expectancy_bps"`
	ProfitFactor         float64 `json:"profit_factor"`
	PositiveContribution float64 `json:"positive_contribution_pct"`
}

type compactLeaveOneOutRow struct {
	RemovedKey    string  `json:"removed_key"`
	EventCount    int     `json:"event_count"`
	ClusterCount  int     `json:"cluster_count"`
	NetBps        float64 `json:"net_bps"`
	ExpectancyBps float64 `json:"expectancy_bps"`
	ProfitFactor  float64 `json:"profit_factor"`
	Pass          bool    `json:"pass"`
}

type compactLeaveOneOutReport struct {
	Supported      bool                    `json:"supported"`
	WorstRemaining *compactLeaveOneOutRow  `json:"worst_remaining,omitempty"`
	Rows           []compactLeaveOneOutRow `json:"rows"`
	Pass           bool                    `json:"pass"`
}

type compactConcentrationReport struct {
	TopSymbolContributionPct  float64               `json:"top_symbol_contribution_pct"`
	TopMonthContributionPct   float64               `json:"top_month_contribution_pct"`
	TopQuarterContributionPct float64               `json:"top_quarter_contribution_pct"`
	TopBucketContributionPct  float64               `json:"top_bucket_contribution_pct"`
	TopBucketBasis            string                `json:"top_bucket_basis"`
	BySymbol                  []compactDimensionRow `json:"by_symbol"`
	ByMonth                   []compactDimensionRow `json:"by_month"`
	ByQuarter                 []compactDimensionRow `json:"by_quarter"`
	ByBucket                  []compactDimensionRow `json:"by_bucket"`
}

type compactDelayReport struct {
	Baseline       *FundingDelayStressMetric `json:"baseline,omitempty"`
	Delay1         *FundingDelayStressMetric `json:"delay_1,omitempty"`
	Delay2         *FundingDelayStressMetric `json:"delay_2,omitempty"`
	Delay1DecayPct *float64                  `json:"delay_1_decay_pct,omitempty"`
	MissingMetrics []string                  `json:"missing_metrics,omitempty"`
}

type compactCandidateReport struct {
	CandidateKey          string                     `json:"candidate_key"`
	Family                string                     `json:"family"`
	Side                  string                     `json:"side"`
	Horizon               string                     `json:"horizon"`
	LeadSymbol            string                     `json:"lead_symbol"`
	EventCount            int                        `json:"event_count"`
	ClusterCount          int                        `json:"cluster_count"`
	MonthsRepresented     int                        `json:"months_represented"`
	SymbolsRepresented    int                        `json:"symbols_represented"`
	QuartersRepresented   int                        `json:"quarters_represented"`
	SampleLabel           string                     `json:"sample_label"`
	BaselineCostBps       *float64                   `json:"baseline_cost_bps,omitempty"`
	Baseline              FundingMetrics             `json:"baseline"`
	CostStress            []FundingCostStressMetric  `json:"cost_stress"`
	DelaySensitivity      compactDelayReport         `json:"delay_sensitivity"`
	Concentration         compactConcentrationReport `json:"concentration"`
	LeaveOneSymbolOut     compactLeaveOneOutReport   `json:"leave_one_symbol_out"`
	LeaveOneMonthOut      compactLeaveOneOutReport   `json:"leave_one_month_out"`
	LeaveOneQuarterOut    compactLeaveOneOutReport   `json:"leave_one_quarter_out"`
	MissingRequiredMetric []string                   `json:"missing_required_metrics"`
	Warnings              []string                   `json:"warnings"`
	Failures              []string                   `json:"failures"`
	FinalLabel            string                     `json:"final_label"`
	PromotionAllowed      bool                       `json:"promotion_allowed"`
	ShadowCandidate       bool                       `json:"shadow_candidate"`
	AkTraderReady         bool                       `json:"ak_trader_ready"`
	RecommendedNextAction string                     `json:"recommended_next_action"`
}

type compactRobustnessReport struct {
	Phase               string                   `json:"phase"`
	CompactSummaryOnly  bool                     `json:"compact_summary_only"`
	RawRequired         bool                     `json:"raw_required"`
	TargetCandidateKey  string                   `json:"target_candidate_key"`
	FinalLabel          string                   `json:"final_label"`
	PromotionAllowed    bool                     `json:"promotion_allowed"`
	ShadowCandidate     bool                     `json:"shadow_candidate"`
	Integrity           compactIntegrityReport   `json:"integrity"`
	Thresholds          compactThresholds        `json:"thresholds"`
	Candidates          []compactCandidateReport `json:"candidates"`
	TargetCandidate     compactCandidateReport   `json:"target_candidate"`
	Warnings            []string                 `json:"warnings"`
	Failures            []string                 `json:"failures"`
	AkTraderIntegration string                   `json:"ak_trader_integration"`
}

type compactPromotionGateReport struct {
	Phase               string                 `json:"phase"`
	FinalLabel          string                 `json:"final_label"`
	PromotionAllowed    bool                   `json:"promotion_allowed"`
	ShadowCandidate     bool                   `json:"shadow_candidate"`
	RawRequired         bool                   `json:"raw_required"`
	IntegrityStatus     string                 `json:"integrity_status"`
	Metrics             compactCandidateReport `json:"metrics"`
	Failures            []string               `json:"failures"`
	Warnings            []string               `json:"warnings"`
	Thresholds          compactThresholds      `json:"thresholds"`
	AkTraderIntegration string                 `json:"ak_trader_integration"`
}

var (
	acrChunks  string
	acrReports string
	acrSymbols string
	acrFrom    string
	acrTo      string
	acrFamily  string
	acrSide    string
	acrHorizon string
)

var analyzeCompactRobustnessCmd = &cobra.Command{
	Use:   "analyze-compact-robustness",
	Short: "Analyze retained funding compact summaries without raw JSONL files",
	RunE: func(cmd *cobra.Command, args []string) error {
		cfg := compactSummaryAnalyzerConfig{
			Symbols:    parseFundingSymbols(acrSymbols),
			Months:     parseFundingMonths(acrFrom, acrTo),
			ChunksDir:  acrChunks,
			ReportsDir: acrReports,
			Family:     strings.TrimSpace(acrFamily),
			Side:       strings.ToLower(strings.TrimSpace(acrSide)),
			Horizon:    strings.TrimSpace(acrHorizon),
		}
		report, gate, err := runCompactRobustnessAnalysis(cfg)
		if err != nil {
			return err
		}
		if err := writeCompactRobustnessOutputs(cfg.ReportsDir, report, gate); err != nil {
			return err
		}
		fmt.Printf("Phase 10.8 compact robustness written to %s\n", filepath.Join(cfg.ReportsDir, "phase10_8_compact_robustness.md"))
		fmt.Printf("Phase 10.8 promotion gate written to %s\n", filepath.Join(cfg.ReportsDir, "phase10_8_promotion_gate.md"))
		return nil
	},
}

func init() {
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrChunks, "chunks-dir", filepath.Join("runs", "reports", "chunks"), "retained chunk summary directory")
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrReports, "reports-dir", filepath.Join("runs", "reports"), "reports output directory")
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrSymbols, "symbols", "", "comma-separated symbols")
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrFrom, "from", "", "from month YYYY-MM")
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrTo, "to", "", "to month YYYY-MM")
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrFamily, "family", "NegativeFundingLong", "candidate family")
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrSide, "side", "long", "candidate side")
	analyzeCompactRobustnessCmd.Flags().StringVar(&acrHorizon, "horizon", "", "candidate horizon")
	rootCmd.AddCommand(analyzeCompactRobustnessCmd)
}

func runCompactRobustnessAnalysis(cfg compactSummaryAnalyzerConfig) (compactRobustnessReport, compactPromotionGateReport, error) {
	cfg = normalizeCompactSummaryAnalyzerConfig(cfg)
	chunks, err := loadCompactSummaryChunks(cfg)
	if err != nil {
		return compactRobustnessReport{}, compactPromotionGateReport{}, err
	}
	thresholds := defaultCompactThresholds()
	integrity := buildCompactIntegrityReport(cfg, chunks)
	candidates, err := buildCompactCandidateReports(cfg, chunks, integrity, thresholds)
	if err != nil {
		return compactRobustnessReport{}, compactPromotionGateReport{}, err
	}
	if len(candidates) == 0 {
		return compactRobustnessReport{}, compactPromotionGateReport{}, fmt.Errorf("no compact summary candidates found for family=%s side=%s horizon=%s", cfg.Family, cfg.Side, cfg.Horizon)
	}
	target := candidates[0]
	report := compactRobustnessReport{
		Phase:               "10.8",
		CompactSummaryOnly:  true,
		RawRequired:         false,
		TargetCandidateKey:  target.CandidateKey,
		FinalLabel:          target.FinalLabel,
		PromotionAllowed:    target.PromotionAllowed,
		ShadowCandidate:     target.ShadowCandidate,
		Integrity:           integrity,
		Thresholds:          thresholds,
		Candidates:          candidates,
		TargetCandidate:     target,
		Warnings:            append([]string(nil), target.Warnings...),
		Failures:            append([]string(nil), target.Failures...),
		AkTraderIntegration: "Phase 10.8 does not perform ak-trader integration or promotion.",
	}
	if integrity.Status == "FAIL" {
		report.Failures = uniqueStrings(append(report.Failures, "summary_only_integrity_fail"))
	}
	gate := compactPromotionGateReport{
		Phase:               "10.8",
		FinalLabel:          target.FinalLabel,
		PromotionAllowed:    target.PromotionAllowed,
		ShadowCandidate:     target.ShadowCandidate,
		RawRequired:         false,
		IntegrityStatus:     integrity.Status,
		Metrics:             target,
		Failures:            append([]string(nil), target.Failures...),
		Warnings:            append([]string(nil), target.Warnings...),
		Thresholds:          thresholds,
		AkTraderIntegration: "Not ready for ak-trader integration in this phase.",
	}
	return report, gate, nil
}

func normalizeCompactSummaryAnalyzerConfig(cfg compactSummaryAnalyzerConfig) compactSummaryAnalyzerConfig {
	if len(cfg.Symbols) == 0 {
		cfg.Symbols = append([]string(nil), defaultFundingSymbols...)
	}
	if len(cfg.Months) == 0 {
		cfg.Months = defaultPhase10FundingMonths()
	}
	if cfg.ChunksDir == "" {
		cfg.ChunksDir = filepath.Join("runs", "reports", "chunks")
	}
	if cfg.ReportsDir == "" {
		cfg.ReportsDir = filepath.Join("runs", "reports")
	}
	if cfg.Family == "" {
		cfg.Family = "NegativeFundingLong"
	}
	if cfg.Side == "" {
		cfg.Side = "long"
	}
	return cfg
}

func defaultCompactThresholds() compactThresholds {
	return compactThresholds{
		MinEventCount:                   30,
		MinClusterCount:                 10,
		CalibrationReadyEventCount:      100,
		TopSymbolContributionFailPct:    50,
		TopMonthContributionFailPct:     40,
		TopQuarterContributionWarnPct:   60,
		TopBucketContributionWarnPct:    60,
		MinBaselinePF:                   1.0,
		MinResearchLeadPF:               1.05,
		MaxDelayDecayFailPct:            75,
		MaxShadowDelayDecayPct:          60,
		MinCost10PFForShadow:            1.0,
		MinCost10ExpectancyForShadowBps: -0.5,
	}
}

func loadCompactSummaryChunks(cfg compactSummaryAnalyzerConfig) ([]compactSummaryChunk, error) {
	chunks := make([]compactSummaryChunk, 0, len(cfg.Symbols)*len(cfg.Months))
	for _, symbol := range cfg.Symbols {
		for _, month := range cfg.Months {
			chunk := compactSummaryChunk{
				Symbol:      symbol,
				Month:       month,
				AlphaPath:   filepath.Join(cfg.ChunksDir, symbol, month+"-alpha-summary.json"),
				SummaryPath: filepath.Join(cfg.ChunksDir, symbol, month+"-funding-summary.json"),
			}
			if data, err := os.ReadFile(chunk.AlphaPath); err != nil {
				chunk.AlphaMissing = true
			} else if err := json.Unmarshal(data, &chunk.AlphaRows); err != nil {
				return nil, fmt.Errorf("parse alpha summary %s: %w", chunk.AlphaPath, err)
			}
			var summary FundingChunkSummary
			if data, err := os.ReadFile(chunk.SummaryPath); err != nil {
				chunk.SummaryMissing = true
			} else if err := json.Unmarshal(data, &summary); err != nil {
				return nil, fmt.Errorf("parse funding summary %s: %w", chunk.SummaryPath, err)
			} else {
				chunk.SummaryStatus = summary.Status
				chunk.ZeroEventMonth = summary.ZeroEventMonth || summary.EventCount == 0
			}
			if len(chunk.AlphaRows) == 0 && !chunk.AlphaMissing {
				chunk.ZeroEventMonth = true
			}
			chunk.UnexplainedZero = chunk.ZeroEventMonth && (chunk.SummaryMissing || (chunk.SummaryStatus != "zero_events" && chunk.SummaryStatus != "unsupported_context" && chunk.SummaryStatus != "missing_data" && chunk.SummaryStatus != "PASS"))
			chunks = append(chunks, chunk)
		}
	}
	return chunks, nil
}

func buildCompactIntegrityReport(cfg compactSummaryAnalyzerConfig, chunks []compactSummaryChunk) compactIntegrityReport {
	monthsFound := make(map[string]struct{})
	symbolsFound := make(map[string]struct{})
	var missing []string
	var zero []string
	var unexplained []string
	for _, chunk := range chunks {
		if !chunk.AlphaMissing {
			monthsFound[chunk.Month] = struct{}{}
			symbolsFound[chunk.Symbol] = struct{}{}
		} else {
			missing = append(missing, chunk.Symbol+"|"+chunk.Month)
		}
		if chunk.ZeroEventMonth {
			zero = append(zero, chunk.Symbol+"|"+chunk.Month)
		}
		if chunk.UnexplainedZero {
			unexplained = append(unexplained, chunk.Symbol+"|"+chunk.Month)
		}
	}
	status := "PASS"
	if len(missing) > 0 || len(unexplained) > 0 {
		status = "FAIL"
	}
	return compactIntegrityReport{
		Status:               status,
		MonthsExpected:       len(cfg.Months),
		MonthsFound:          len(monthsFound),
		SymbolsExpected:      len(cfg.Symbols),
		SymbolsFound:         len(symbolsFound),
		MissingSummaries:     missing,
		ZeroEventSummaries:   zero,
		UnexplainedZeroEvent: unexplained,
		RawRequired:          false,
	}
}

func buildCompactCandidateReports(cfg compactSummaryAnalyzerConfig, chunks []compactSummaryChunk, integrity compactIntegrityReport, thresholds compactThresholds) ([]compactCandidateReport, error) {
	byCandidate := make(map[string][]FundingAlphaSummaryRow)
	for _, chunk := range chunks {
		for _, row := range chunk.AlphaRows {
			key := strings.Join([]string{row.Family, strings.ToLower(row.Side), row.Horizon}, "|")
			byCandidate[key] = append(byCandidate[key], row)
		}
	}
	keys := make([]string, 0, len(byCandidate))
	for key := range byCandidate {
		parts := strings.Split(key, "|")
		if len(parts) != 3 {
			continue
		}
		if cfg.Family != "" && parts[0] != cfg.Family {
			continue
		}
		if cfg.Side != "" && parts[1] != cfg.Side {
			continue
		}
		if cfg.Horizon != "" && parts[2] != cfg.Horizon {
			continue
		}
		keys = append(keys, key)
	}
	sort.Strings(keys)
	out := make([]compactCandidateReport, 0, len(keys))
	for _, key := range keys {
		out = append(out, evaluateCompactCandidate(key, byCandidate[key], integrity, thresholds))
	}
	sort.Slice(out, func(i, j int) bool { return compactCandidateBetter(out[i], out[j]) })
	return out, nil
}

func evaluateCompactCandidate(candidateKey string, rows []FundingAlphaSummaryRow, integrity compactIntegrityReport, thresholds compactThresholds) compactCandidateReport {
	parts := strings.Split(candidateKey, "|")
	baseline := aggregateMetricsFromAlphaSummaries(rows)
	bySymbol := aggregateCompactDimensions(rows, "symbol")
	byMonth := aggregateCompactDimensions(rows, "month")
	byQuarter := aggregateCompactDimensions(rows, "quarter")
	byBucket, bucketBasis := aggregateCompactBucketDimensions(rows)
	delay := compactDelaySensitivity(baseline.DelayStress)
	missing := compactMissingRequiredMetrics(baseline, delay, byMonth, byQuarter)
	symbolLOO := compactLeaveOneOut(bySymbol)
	monthLOO := compactLeaveOneOut(byMonth)
	quarterLOO := compactLeaveOneOut(byQuarter)
	report := compactCandidateReport{
		CandidateKey:          candidateKey,
		Family:                parts[0],
		Side:                  parts[1],
		Horizon:               parts[2],
		LeadSymbol:            topContributionKey(bySymbol),
		EventCount:            baseline.EventCount,
		ClusterCount:          baseline.ClusterCount,
		MonthsRepresented:     distinctDimensionCount(rows, "month"),
		SymbolsRepresented:    distinctDimensionCount(rows, "symbol"),
		QuartersRepresented:   distinctDimensionCount(rows, "quarter"),
		SampleLabel:           compactSampleLabel(baseline.EventCount, baseline.ClusterCount, thresholds),
		Baseline:              baseline,
		CostStress:            baseline.CostStress,
		DelaySensitivity:      delay,
		Concentration:         compactConcentration(bySymbol, byMonth, byQuarter, byBucket, bucketBasis),
		LeaveOneSymbolOut:     symbolLOO,
		LeaveOneMonthOut:      monthLOO,
		LeaveOneQuarterOut:    quarterLOO,
		MissingRequiredMetric: missing,
		AkTraderReady:         false,
	}
	if baseline.BaselineCostBps > 0 {
		report.BaselineCostBps = &baseline.BaselineCostBps
	}
	label, allowed, shadow, failures, warnings, next := compactPromotionDecision(report, integrity, thresholds)
	report.FinalLabel = label
	report.PromotionAllowed = allowed
	report.ShadowCandidate = shadow
	report.Failures = failures
	report.Warnings = warnings
	report.RecommendedNextAction = next
	return report
}

func aggregateCompactDimensions(rows []FundingAlphaSummaryRow, level string) []compactDimensionRow {
	grouped := make(map[string][]FundingAlphaSummaryRow)
	for _, row := range rows {
		var key string
		switch level {
		case "symbol":
			key = row.Symbol
		case "month":
			key = row.Month
		case "quarter":
			key = row.Quarter
		}
		grouped[key] = append(grouped[key], row)
	}
	out := make([]compactDimensionRow, 0, len(grouped))
	for key, groupRows := range grouped {
		agg := aggregateMetricsFromAlphaSummaries(groupRows)
		out = append(out, compactDimensionRow{
			Key:            key,
			EventCount:     agg.EventCount,
			ClusterCount:   agg.ClusterCount,
			GrossProfitBps: agg.GrossProfitBps,
			GrossLossBps:   agg.GrossLossBps,
			NetBps:         roundMetric(agg.GrossProfitBps - agg.GrossLossBps),
			ExpectancyBps:  agg.ExpectancyCombined_5bpsBps,
			ProfitFactor:   agg.PFCombined_5bps,
		})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Key < out[j].Key })
	addPositiveContribution(out)
	return out
}

func aggregateCompactBucketDimensions(rows []FundingAlphaSummaryRow) ([]compactDimensionRow, string) {
	agg := aggregateMetricsFromAlphaSummaries(rows)
	var filtered []FundingBucketMetric
	basis := "missing"
	for _, bucketType := range []string{"funding_x_regime", "regime", "funding_severity"} {
		for _, row := range agg.BucketMetrics {
			if row.BucketType == bucketType {
				filtered = append(filtered, row)
			}
		}
		if len(filtered) > 0 {
			basis = bucketType
			break
		}
	}
	out := make([]compactDimensionRow, 0, len(filtered))
	for _, row := range filtered {
		out = append(out, compactDimensionRow{
			Key:            row.Bucket,
			EventCount:     row.EventCount,
			ClusterCount:   row.DeClusteredEventCount,
			GrossProfitBps: row.GrossProfitBps,
			GrossLossBps:   row.GrossLossBps,
			NetBps:         row.NetBps,
			ExpectancyBps:  row.ExpectancyBps,
			ProfitFactor:   row.PF,
		})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Key < out[j].Key })
	addPositiveContribution(out)
	return out, basis
}

func compactDelaySensitivity(rows []FundingDelayStressMetric) compactDelayReport {
	var report compactDelayReport
	for i := range rows {
		row := rows[i]
		switch row.DelayCandles {
		case 0:
			report.Baseline = &row
		case 1:
			report.Delay1 = &row
		case 2:
			report.Delay2 = &row
		}
	}
	if report.Baseline == nil {
		report.MissingMetrics = append(report.MissingMetrics, "delay_0")
	}
	if report.Delay1 == nil || !report.Delay1.Available {
		report.MissingMetrics = append(report.MissingMetrics, "delay_1")
	}
	if report.Delay2 == nil {
		report.MissingMetrics = append(report.MissingMetrics, "delay_2")
	}
	if report.Baseline != nil && report.Delay1 != nil && report.Baseline.ExpectancyBps != 0 {
		decay := roundMetric((1 - (report.Delay1.ExpectancyBps / report.Baseline.ExpectancyBps)) * 100)
		report.Delay1DecayPct = &decay
	}
	return report
}

func compactConcentration(bySymbol, byMonth, byQuarter, byBucket []compactDimensionRow, bucketBasis string) compactConcentrationReport {
	return compactConcentrationReport{
		TopSymbolContributionPct:  topPositiveContribution(bySymbol),
		TopMonthContributionPct:   topPositiveContribution(byMonth),
		TopQuarterContributionPct: topPositiveContribution(byQuarter),
		TopBucketContributionPct:  topPositiveContribution(byBucket),
		TopBucketBasis:            bucketBasis,
		BySymbol:                  bySymbol,
		ByMonth:                   byMonth,
		ByQuarter:                 byQuarter,
		ByBucket:                  byBucket,
	}
}

func compactLeaveOneOut(rows []compactDimensionRow) compactLeaveOneOutReport {
	if len(rows) == 0 {
		return compactLeaveOneOutReport{}
	}
	out := make([]compactLeaveOneOutRow, 0, len(rows))
	pass := true
	for _, removed := range rows {
		var grossProfit, grossLoss float64
		var events, clusters int
		for _, row := range rows {
			if row.Key == removed.Key {
				continue
			}
			grossProfit += row.GrossProfitBps
			grossLoss += row.GrossLossBps
			events += row.EventCount
			clusters += row.ClusterCount
		}
		net := roundMetric(grossProfit - grossLoss)
		expectancy := 0.0
		if events > 0 {
			expectancy = roundMetric(net / float64(events))
		}
		row := compactLeaveOneOutRow{
			RemovedKey:    removed.Key,
			EventCount:    events,
			ClusterCount:  clusters,
			NetBps:        net,
			ExpectancyBps: expectancy,
			ProfitFactor:  roundMetric(safePF(grossProfit, grossLoss)),
			Pass:          events > 0 && expectancy > 0 && safePF(grossProfit, grossLoss) > 1.0,
		}
		if !row.Pass {
			pass = false
		}
		out = append(out, row)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ExpectancyBps < out[j].ExpectancyBps })
	report := compactLeaveOneOutReport{Supported: true, Rows: out, Pass: pass}
	if len(out) > 0 {
		report.WorstRemaining = &out[0]
	}
	return report
}

func compactMissingRequiredMetrics(metrics FundingMetrics, delay compactDelayReport, byMonth, byQuarter []compactDimensionRow) []string {
	var missing []string
	if metrics.BaselineCostBps == 0 {
		missing = append(missing, "baseline_cost_bps")
	}
	if !hasCostMetric(metrics.CostStress, 5) {
		missing = append(missing, "cost_5")
	}
	if !hasCostMetric(metrics.CostStress, 7.5) {
		missing = append(missing, "cost_7_5")
	}
	if !hasCostMetric(metrics.CostStress, 10) {
		missing = append(missing, "cost_10")
	}
	if reportMissing(delay.MissingMetrics, "delay_1") {
		missing = append(missing, "delay_1")
	}
	if len(byMonth) == 0 {
		missing = append(missing, "by_month")
	}
	if len(byQuarter) == 0 {
		missing = append(missing, "by_quarter")
	}
	return uniqueStrings(missing)
}

func compactSampleLabel(eventCount, clusterCount int, thresholds compactThresholds) string {
	if eventCount < thresholds.MinEventCount || clusterCount < thresholds.MinClusterCount {
		return "insufficient_sample"
	}
	if eventCount < thresholds.CalibrationReadyEventCount {
		return "early_sample"
	}
	return "calibration_ready"
}

func compactPromotionDecision(report compactCandidateReport, integrity compactIntegrityReport, thresholds compactThresholds) (string, bool, bool, []string, []string, string) {
	failures := append([]string(nil), report.MissingRequiredMetric...)
	warnings := append([]string(nil), report.MissingRequiredMetric...)
	if integrity.Status == "FAIL" {
		failures = append(failures, "integrity_fail")
	}
	if report.SampleLabel == "insufficient_sample" {
		failures = append(failures, "insufficient_sample")
	}
	if report.Baseline.ExpectancyCombined_5bpsBps <= 0 {
		failures = append(failures, "baseline_expectancy_non_positive")
	}
	if report.Baseline.PFCombined_5bps <= thresholds.MinBaselinePF {
		failures = append(failures, "baseline_pf_non_positive")
	}

	cost7 := metricByCost(report.CostStress, 7.5)
	cost10 := metricByCost(report.CostStress, 10)
	if cost7 == nil {
		failures = append(failures, "cost_7_5_missing")
	} else if cost7.ExpectancyBps <= 0 || cost7.PF <= 1.0 {
		failures = append(failures, "cost_7_5_fail")
	}
	if cost10 == nil {
		failures = append(failures, "cost_10_missing")
	} else if cost10.ExpectancyBps <= 0 || cost10.PF <= 1.0 {
		warnings = append(warnings, "cost_10_fragile")
	}

	if report.Concentration.TopSymbolContributionPct > thresholds.TopSymbolContributionFailPct {
		failures = append(failures, "concentration_symbol")
	}
	if report.Concentration.TopMonthContributionPct > thresholds.TopMonthContributionFailPct {
		failures = append(failures, "concentration_month")
	}
	if report.Concentration.TopQuarterContributionPct > thresholds.TopQuarterContributionWarnPct {
		warnings = append(warnings, "concentration_quarter")
	}
	if report.Concentration.TopBucketContributionPct > thresholds.TopBucketContributionWarnPct {
		warnings = append(warnings, "concentration_bucket")
	}
	if !report.LeaveOneSymbolOut.Pass {
		failures = append(failures, "leave_one_symbol_out_fail")
	}
	if !report.LeaveOneMonthOut.Pass {
		failures = append(failures, "leave_one_month_out_fail")
	}
	if !report.LeaveOneQuarterOut.Pass {
		failures = append(failures, "leave_one_quarter_out_fail")
	}
	delayFail := false
	if report.DelaySensitivity.Delay1 == nil || !report.DelaySensitivity.Delay1.Available {
		failures = append(failures, "delay_1_missing")
		delayFail = true
	} else {
		if report.DelaySensitivity.Delay1.ExpectancyBps <= 0 {
			failures = append(failures, "delay_1_expectancy_non_positive")
			delayFail = true
		}
		if report.DelaySensitivity.Delay1DecayPct != nil && *report.DelaySensitivity.Delay1DecayPct > thresholds.MaxDelayDecayFailPct {
			failures = append(failures, "delay_1_decay_fail")
			delayFail = true
		}
	}

	failures = uniqueStrings(failures)
	warnings = uniqueStrings(warnings)
	if containsAny(failures, []string{"integrity_fail", "insufficient_sample", "baseline_expectancy_non_positive", "baseline_pf_non_positive"}) {
		return "REJECTED", false, false, failures, warnings, "Fix baseline integrity/sample issues before any promotion review."
	}
	if len(report.MissingRequiredMetric) > 0 || containsAny(failures, []string{"cost_7_5_fail", "leave_one_symbol_out_fail", "leave_one_month_out_fail", "leave_one_quarter_out_fail", "concentration_symbol", "concentration_month"}) || delayFail {
		return "FRAGILE_RESEARCH_LEAD", false, false, failures, warnings, "Expand retained-summary coverage or improve robustness before promotion."
	}
	shadowEligible := report.Baseline.PFCombined_5bps > thresholds.MinResearchLeadPF &&
		cost7 != nil && cost7.ExpectancyBps > 0 && cost7.PF > thresholds.MinResearchLeadPF &&
		cost10 != nil && cost10.ExpectancyBps >= thresholds.MinCost10ExpectancyForShadowBps && cost10.PF >= thresholds.MinCost10PFForShadow &&
		report.Concentration.TopQuarterContributionPct <= thresholds.TopQuarterContributionWarnPct &&
		report.Concentration.TopBucketContributionPct <= thresholds.TopBucketContributionWarnPct &&
		report.SampleLabel == "calibration_ready" &&
		report.DelaySensitivity.Delay1DecayPct != nil && *report.DelaySensitivity.Delay1DecayPct <= thresholds.MaxShadowDelayDecayPct &&
		len(warnings) == 0
	if shadowEligible {
		return "SHADOW_CANDIDATE", true, true, failures, warnings, "Retained summaries support a shadow-candidate review, but ak-trader integration is still out of scope."
	}
	return "RESEARCH_LEAD", true, false, failures, warnings, "Candidate remains a research lead; monitor concentration and 10 bps stress before any promotion."
}

func compactCandidateBetter(a, b compactCandidateReport) bool {
	rank := map[string]int{"SHADOW_CANDIDATE": 4, "RESEARCH_LEAD": 3, "FRAGILE_RESEARCH_LEAD": 2, "REJECTED": 1}
	if rank[a.FinalLabel] != rank[b.FinalLabel] {
		return rank[a.FinalLabel] > rank[b.FinalLabel]
	}
	a7 := metricByCost(a.CostStress, 7.5)
	b7 := metricByCost(b.CostStress, 7.5)
	a7exp, b7exp := -1e18, -1e18
	if a7 != nil {
		a7exp = a7.ExpectancyBps
	}
	if b7 != nil {
		b7exp = b7.ExpectancyBps
	}
	if a7exp != b7exp {
		return a7exp > b7exp
	}
	if a.Baseline.PFCombined_5bps != b.Baseline.PFCombined_5bps {
		return a.Baseline.PFCombined_5bps > b.Baseline.PFCombined_5bps
	}
	return a.EventCount > b.EventCount
}

func addPositiveContribution(rows []compactDimensionRow) {
	total := 0.0
	for _, row := range rows {
		if row.NetBps > 0 {
			total += row.NetBps
		}
	}
	for i := range rows {
		rows[i].PositiveContribution = percentOfPositive(rows[i].NetBps, total)
	}
}

func topPositiveContribution(rows []compactDimensionRow) float64 {
	best := 0.0
	for _, row := range rows {
		if row.PositiveContribution > best {
			best = row.PositiveContribution
		}
	}
	return roundMetric(best)
}

func topContributionKey(rows []compactDimensionRow) string {
	bestKey := ""
	bestPct := -1.0
	for _, row := range rows {
		if row.PositiveContribution > bestPct {
			bestPct = row.PositiveContribution
			bestKey = row.Key
		}
	}
	return bestKey
}

func percentOfPositive(net, total float64) float64 {
	if net <= 0 || total <= 0 {
		return 0
	}
	return roundMetric(net / total * 100)
}

func distinctDimensionCount(rows []FundingAlphaSummaryRow, level string) int {
	seen := make(map[string]struct{})
	for _, row := range rows {
		switch level {
		case "month":
			seen[row.Month] = struct{}{}
		case "symbol":
			seen[row.Symbol] = struct{}{}
		case "quarter":
			seen[row.Quarter] = struct{}{}
		}
	}
	return len(seen)
}

func hasCostMetric(rows []FundingCostStressMetric, target float64) bool {
	return metricByCost(rows, target) != nil
}

func metricByCost(rows []FundingCostStressMetric, target float64) *FundingCostStressMetric {
	for i := range rows {
		if rows[i].CostBps == target {
			return &rows[i]
		}
	}
	return nil
}

func reportMissing(values []string, target string) bool {
	for _, value := range values {
		if value == target {
			return true
		}
	}
	return false
}

func containsAny(values, needles []string) bool {
	seen := make(map[string]struct{}, len(values))
	for _, value := range values {
		seen[value] = struct{}{}
	}
	for _, needle := range needles {
		if _, ok := seen[needle]; ok {
			return true
		}
	}
	return false
}

func uniqueStrings(values []string) []string {
	if len(values) == 0 {
		return nil
	}
	seen := make(map[string]struct{}, len(values))
	out := make([]string, 0, len(values))
	for _, value := range values {
		if value == "" {
			continue
		}
		if _, ok := seen[value]; ok {
			continue
		}
		seen[value] = struct{}{}
		out = append(out, value)
	}
	sort.Strings(out)
	return out
}

func writeCompactRobustnessOutputs(reportsDir string, report compactRobustnessReport, gate compactPromotionGateReport) error {
	if err := atomicWriteJSONFile(filepath.Join(reportsDir, "phase10_8_compact_robustness.json"), report, "", "  ", 0644); err != nil {
		return err
	}
	if err := atomicWriteJSONFile(filepath.Join(reportsDir, "phase10_8_promotion_gate.json"), gate, "", "  ", 0644); err != nil {
		return err
	}
	if err := atomicWriteFile(filepath.Join(reportsDir, "phase10_8_compact_robustness.md"), []byte(renderCompactRobustnessMarkdown(report)), 0644); err != nil {
		return err
	}
	return atomicWriteFile(filepath.Join(reportsDir, "phase10_8_promotion_gate.md"), []byte(renderCompactPromotionMarkdown(gate)), 0644)
}

func renderCompactRobustnessMarkdown(report compactRobustnessReport) string {
	target := report.TargetCandidate
	var sb strings.Builder
	sb.WriteString("# Phase 10.8 Compact Robustness\n\n")
	sb.WriteString(fmt.Sprintf("- Final label: `%s`\n", report.FinalLabel))
	sb.WriteString(fmt.Sprintf("- Candidate/family/side/horizon evaluated: `%s` `%s` `%s`\n", target.CandidateKey, target.Family, target.Horizon))
	sb.WriteString(fmt.Sprintf("- Compact-summary-only status: `%t`\n", report.CompactSummaryOnly))
	sb.WriteString(fmt.Sprintf("- Raw files required: `%t`\n", report.RawRequired))
	sb.WriteString(fmt.Sprintf("- ak-trader integration: `%s`\n\n", report.AkTraderIntegration))

	sb.WriteString("## Integrity\n\n")
	sb.WriteString("| Metric | Value |\n|---|---|\n")
	sb.WriteString(fmt.Sprintf("| status | `%s` |\n", report.Integrity.Status))
	sb.WriteString(fmt.Sprintf("| months expected/found | `%d / %d` |\n", report.Integrity.MonthsExpected, report.Integrity.MonthsFound))
	sb.WriteString(fmt.Sprintf("| symbols expected/found | `%d / %d` |\n", report.Integrity.SymbolsExpected, report.Integrity.SymbolsFound))
	sb.WriteString(fmt.Sprintf("| missing summaries | `%d` |\n", len(report.Integrity.MissingSummaries)))
	sb.WriteString(fmt.Sprintf("| zero-event summaries | `%d` |\n", len(report.Integrity.ZeroEventSummaries)))
	sb.WriteString(fmt.Sprintf("| missing required metrics | `%d` |\n\n", len(target.MissingRequiredMetric)))

	sb.WriteString("## Baseline Metrics\n\n")
	sb.WriteString("| Metric | Value |\n|---|---|\n")
	sb.WriteString(fmt.Sprintf("| event_count | `%d` |\n", target.EventCount))
	sb.WriteString(fmt.Sprintf("| cluster_count | `%d` |\n", target.ClusterCount))
	sb.WriteString(fmt.Sprintf("| months represented | `%d` |\n", target.MonthsRepresented))
	sb.WriteString(fmt.Sprintf("| symbols represented | `%d` |\n", target.SymbolsRepresented))
	if target.BaselineCostBps != nil {
		sb.WriteString(fmt.Sprintf("| baseline cost bps | `%.1f` |\n", *target.BaselineCostBps))
	} else {
		sb.WriteString("| baseline cost bps | `MISSING` |\n")
	}
	sb.WriteString(fmt.Sprintf("| expectancy bps | `%.6f` |\n", target.Baseline.ExpectancyCombined_5bpsBps))
	sb.WriteString(fmt.Sprintf("| profit factor | `%.6f` |\n\n", target.Baseline.PFCombined_5bps))

	sb.WriteString("## Cost Stress\n\n")
	sb.WriteString("| Cost Bps | Event Count | Net Bps | Expectancy Bps | PF |\n|---|---:|---:|---:|---:|\n")
	for _, row := range target.CostStress {
		sb.WriteString(fmt.Sprintf("| `%.1f` | `%d` | `%.6f` | `%.6f` | `%.6f` |\n", row.CostBps, row.EventCount, row.NetBps, row.ExpectancyBps, row.PF))
	}
	sb.WriteString("\n")
	writeCompactDimensionTable(&sb, "Concentration By Symbol", target.Concentration.BySymbol)
	writeCompactDimensionTable(&sb, "Concentration By Month", target.Concentration.ByMonth)
	writeCompactDimensionTable(&sb, "Concentration By Quarter", target.Concentration.ByQuarter)
	writeCompactLeaveOneOutTable(&sb, "Leave-One-Symbol-Out", target.LeaveOneSymbolOut)
	writeCompactLeaveOneOutTable(&sb, "Leave-One-Month-Out", target.LeaveOneMonthOut)
	writeCompactLeaveOneOutTable(&sb, "Leave-One-Quarter-Out", target.LeaveOneQuarterOut)

	sb.WriteString("## Delay Sensitivity\n\n")
	sb.WriteString("| Delay | Available | Expectancy Bps | PF |\n|---|---|---:|---:|\n")
	for _, row := range []*FundingDelayStressMetric{target.DelaySensitivity.Baseline, target.DelaySensitivity.Delay1, target.DelaySensitivity.Delay2} {
		if row == nil {
			continue
		}
		sb.WriteString(fmt.Sprintf("| `%s` | `%t` | `%.6f` | `%.6f` |\n", row.Label, row.Available, row.ExpectancyBps, row.PF))
	}
	if target.DelaySensitivity.Delay1DecayPct != nil {
		sb.WriteString(fmt.Sprintf("\n- delay_1 decay from baseline: `%.6f%%`\n", *target.DelaySensitivity.Delay1DecayPct))
	}

	sb.WriteString("\n## Blockers\n\n")
	if len(target.Failures) == 0 {
		sb.WriteString("- none\n")
	} else {
		for _, failure := range target.Failures {
			sb.WriteString(fmt.Sprintf("- `%s`\n", failure))
		}
	}
	sb.WriteString("\n## Recommended Next Action\n\n")
	sb.WriteString(fmt.Sprintf("- %s\n", target.RecommendedNextAction))
	return sb.String()
}

func writeCompactDimensionTable(sb *strings.Builder, title string, rows []compactDimensionRow) {
	sb.WriteString(fmt.Sprintf("## %s\n\n", title))
	sb.WriteString("| Key | Event Count | Cluster Count | Net Bps | Expectancy Bps | PF | Positive Contribution % |\n|---|---:|---:|---:|---:|---:|---:|\n")
	for _, row := range rows {
		sb.WriteString(fmt.Sprintf("| `%s` | `%d` | `%d` | `%.6f` | `%.6f` | `%.6f` | `%.6f` |\n", row.Key, row.EventCount, row.ClusterCount, row.NetBps, row.ExpectancyBps, row.ProfitFactor, row.PositiveContribution))
	}
	sb.WriteString("\n")
}

func writeCompactLeaveOneOutTable(sb *strings.Builder, title string, report compactLeaveOneOutReport) {
	sb.WriteString(fmt.Sprintf("## %s\n\n", title))
	sb.WriteString("| Removed | Event Count | Cluster Count | Net Bps | Expectancy Bps | PF | Pass |\n|---|---:|---:|---:|---:|---:|---|\n")
	for _, row := range report.Rows {
		sb.WriteString(fmt.Sprintf("| `%s` | `%d` | `%d` | `%.6f` | `%.6f` | `%.6f` | `%t` |\n", row.RemovedKey, row.EventCount, row.ClusterCount, row.NetBps, row.ExpectancyBps, row.ProfitFactor, row.Pass))
	}
	sb.WriteString("\n")
}

func renderCompactPromotionMarkdown(report compactPromotionGateReport) string {
	var sb strings.Builder
	sb.WriteString("# Phase 10.8 Promotion Gate\n\n")
	sb.WriteString(fmt.Sprintf("- Final label: `%s`\n", report.FinalLabel))
	sb.WriteString(fmt.Sprintf("- Promotion allowed: `%t`\n", report.PromotionAllowed))
	sb.WriteString(fmt.Sprintf("- Shadow candidate: `%t`\n", report.ShadowCandidate))
	sb.WriteString(fmt.Sprintf("- Raw files required: `%t`\n", report.RawRequired))
	sb.WriteString(fmt.Sprintf("- Integrity status: `%s`\n", report.IntegrityStatus))
	sb.WriteString(fmt.Sprintf("- Candidate: `%s`\n", report.Metrics.CandidateKey))
	sb.WriteString(fmt.Sprintf("- ak-trader integration: `%s`\n\n", report.AkTraderIntegration))
	sb.WriteString("## Failures\n\n")
	if len(report.Failures) == 0 {
		sb.WriteString("- none\n")
	} else {
		for _, failure := range report.Failures {
			sb.WriteString(fmt.Sprintf("- `%s`\n", failure))
		}
	}
	sb.WriteString("\n## Warnings\n\n")
	if len(report.Warnings) == 0 {
		sb.WriteString("- none\n")
	} else {
		for _, warning := range report.Warnings {
			sb.WriteString(fmt.Sprintf("- `%s`\n", warning))
		}
	}
	return sb.String()
}
