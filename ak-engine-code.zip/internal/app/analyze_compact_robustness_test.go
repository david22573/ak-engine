package app

import "testing"

func TestCompactMissingMetricDetection(t *testing.T) {
	metrics := FundingMetrics{
		EventCount:                 120,
		ClusterCount:               20,
		PFCombined_5bps:            1.2,
		ExpectancyCombined_5bpsBps: 2,
		CostStress: []FundingCostStressMetric{
			{CostBps: 5, ExpectancyBps: 2, PF: 1.2},
		},
	}
	delay := compactDelayReport{MissingMetrics: []string{"delay_1"}}
	missing := compactMissingRequiredMetrics(metrics, delay, []compactDimensionRow{{Key: "2025-01"}}, []compactDimensionRow{{Key: "2025-Q1"}})
	if !containsAny(missing, []string{"baseline_cost_bps", "cost_7_5", "cost_10", "delay_1"}) {
		t.Fatalf("missing=%v", missing)
	}
}

func TestCompactConcentrationAndLeaveOneOutFailures(t *testing.T) {
	rows := []compactDimensionRow{
		{Key: "A", EventCount: 50, ClusterCount: 10, GrossProfitBps: 100, GrossLossBps: 20, NetBps: 80, ExpectancyBps: 1.6, ProfitFactor: 5},
		{Key: "B", EventCount: 50, ClusterCount: 10, GrossProfitBps: 10, GrossLossBps: 40, NetBps: -30, ExpectancyBps: -0.6, ProfitFactor: 0.25},
	}
	addPositiveContribution(rows)
	if got := topPositiveContribution(rows); got <= 50 {
		t.Fatalf("top contribution=%f want >50", got)
	}
	loo := compactLeaveOneOut(rows)
	if loo.Pass {
		t.Fatalf("expected leave-one-out fail")
	}
	if loo.WorstRemaining == nil || loo.WorstRemaining.Pass {
		t.Fatalf("expected failing worst remaining row: %+v", loo.WorstRemaining)
	}
}

func TestCompactCostStressAndDelayDecision(t *testing.T) {
	report := compactCandidateReport{
		CandidateKey: "NegativeFundingLong|long|60m",
		SampleLabel:  "calibration_ready",
		Baseline: FundingMetrics{
			BaselineCostBps:            5,
			EventCount:                 120,
			ClusterCount:               20,
			PFCombined_5bps:            1.2,
			ExpectancyCombined_5bpsBps: 3,
		},
		CostStress: []FundingCostStressMetric{
			{CostBps: 5, ExpectancyBps: 3, PF: 1.2},
			{CostBps: 7.5, ExpectancyBps: 1, PF: 1.1},
			{CostBps: 10, ExpectancyBps: 0.2, PF: 1.01},
		},
		Concentration:      compactConcentrationReport{},
		LeaveOneSymbolOut:  compactLeaveOneOutReport{Supported: true, Pass: true},
		LeaveOneMonthOut:   compactLeaveOneOutReport{Supported: true, Pass: true},
		LeaveOneQuarterOut: compactLeaveOneOutReport{Supported: true, Pass: true},
		DelaySensitivity: compactDelayReport{
			Baseline:       &FundingDelayStressMetric{DelayCandles: 0, Label: "baseline", Available: true, ExpectancyBps: 3, PF: 1.2},
			Delay1:         &FundingDelayStressMetric{DelayCandles: 1, Label: "delay_1", Available: true, ExpectancyBps: 2.1, PF: 1.1},
			Delay1DecayPct: func() *float64 { v := 30.0; return &v }(),
		},
	}
	label, allowed, shadow, failures, _, _ := compactPromotionDecision(report, compactIntegrityReport{Status: "PASS"}, defaultCompactThresholds())
	if label != "SHADOW_CANDIDATE" || !allowed || !shadow || len(failures) != 0 {
		t.Fatalf("label=%s allowed=%t shadow=%t failures=%v", label, allowed, shadow, failures)
	}

	report.DelaySensitivity.Delay1.ExpectancyBps = -0.1
	label, allowed, shadow, failures, _, _ = compactPromotionDecision(report, compactIntegrityReport{Status: "PASS"}, defaultCompactThresholds())
	if label != "FRAGILE_RESEARCH_LEAD" || allowed || shadow || !containsAny(failures, []string{"delay_1_expectancy_non_positive"}) {
		t.Fatalf("label=%s allowed=%t shadow=%t failures=%v", label, allowed, shadow, failures)
	}
}

func TestCompactLabelAssignmentCases(t *testing.T) {
	base := compactCandidateReport{
		CandidateKey: "NegativeFundingLong|long|60m",
		SampleLabel:  "calibration_ready",
		Baseline: FundingMetrics{
			BaselineCostBps:            5,
			EventCount:                 120,
			ClusterCount:               20,
			PFCombined_5bps:            1.2,
			ExpectancyCombined_5bpsBps: 2,
		},
		CostStress: []FundingCostStressMetric{
			{CostBps: 5, ExpectancyBps: 2, PF: 1.2},
			{CostBps: 7.5, ExpectancyBps: 0.8, PF: 1.08},
			{CostBps: 10, ExpectancyBps: 0.1, PF: 1.0},
		},
		Concentration:      compactConcentrationReport{},
		LeaveOneSymbolOut:  compactLeaveOneOutReport{Supported: true, Pass: true},
		LeaveOneMonthOut:   compactLeaveOneOutReport{Supported: true, Pass: true},
		LeaveOneQuarterOut: compactLeaveOneOutReport{Supported: true, Pass: true},
		DelaySensitivity: compactDelayReport{
			Baseline:       &FundingDelayStressMetric{DelayCandles: 0, Label: "baseline", Available: true, ExpectancyBps: 2, PF: 1.2},
			Delay1:         &FundingDelayStressMetric{DelayCandles: 1, Label: "delay_1", Available: true, ExpectancyBps: 1.4, PF: 1.1},
			Delay1DecayPct: func() *float64 { v := 30.0; return &v }(),
		},
	}
	if label, _, _, _, _, _ := compactPromotionDecision(base, compactIntegrityReport{Status: "PASS"}, defaultCompactThresholds()); label != "SHADOW_CANDIDATE" {
		t.Fatalf("shadow case label=%s", label)
	}

	research := base
	research.CostStress[2] = FundingCostStressMetric{CostBps: 10, ExpectancyBps: -0.4, PF: 0.99}
	if label, allowed, shadow, _, warnings, _ := compactPromotionDecision(research, compactIntegrityReport{Status: "PASS"}, defaultCompactThresholds()); label != "RESEARCH_LEAD" || !allowed || shadow || len(warnings) == 0 {
		t.Fatalf("research label=%s allowed=%t shadow=%t warnings=%v", label, allowed, shadow, warnings)
	}

	fragile := base
	fragile.Concentration.TopMonthContributionPct = 55
	if label, allowed, shadow, failures, _, _ := compactPromotionDecision(fragile, compactIntegrityReport{Status: "PASS"}, defaultCompactThresholds()); label != "FRAGILE_RESEARCH_LEAD" || allowed || shadow || !containsAny(failures, []string{"concentration_month"}) {
		t.Fatalf("fragile label=%s allowed=%t shadow=%t failures=%v", label, allowed, shadow, failures)
	}

	rejected := base
	rejected.Baseline.ExpectancyCombined_5bpsBps = -1
	if label, allowed, shadow, failures, _, _ := compactPromotionDecision(rejected, compactIntegrityReport{Status: "PASS"}, defaultCompactThresholds()); label != "REJECTED" || allowed || shadow || !containsAny(failures, []string{"baseline_expectancy_non_positive"}) {
		t.Fatalf("rejected label=%s allowed=%t shadow=%t failures=%v", label, allowed, shadow, failures)
	}
}
